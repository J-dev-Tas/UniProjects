package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class EditProfile extends AppCompatActivity implements View.OnClickListener{
    EditText height,weight;
    Button metric,imperial,save;
    String heightTextValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        height = findViewById(R.id.height);
        weight = findViewById(R.id.weight);
        metric = findViewById(R.id.metric);
        imperial = findViewById(R.id.imperial);
        save = findViewById(R.id.save);
        heightTextValue = height.getText().toString();
        save.setOnClickListener(this);
        metric.setOnClickListener(this);
        imperial.setOnClickListener(this);
        if(savedInstanceState != null){
            height.setText( savedInstanceState.getString("text") ); //setting the saved value to the TextView
        }
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                heightTextValue = height.getText().toString();
                height.setText(heightTextValue);
            }
        });



    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.metric:
                metric();

                break;
            case R.id.imperial:
                imperial();
                break;

            case R.id.save:

        }
    }

    public void metric(){
        double heightt = Double.valueOf(height.getText().toString());
        double weightt = Double.valueOf(weight.getText().toString());
        weightt = weightt/2.205;
        heightt = heightt*2.54;
        DecimalFormat df = new DecimalFormat("#.00");
        String w = df.format(weightt);
        String h = df.format(heightt);
        height.setText(h );
        weight.setText(w );
    }

    public void imperial(){
        double heightt = Double.valueOf(height.getText().toString());
        double weightt = Double.valueOf(weight.getText().toString());
        weightt = weightt*2.205;
        heightt = heightt/2.54;
        DecimalFormat df = new DecimalFormat("#.00");
        String w = df.format(weightt);
        String h = df.format(heightt);
        height.setText(h);
        weight.setText(w);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        heightTextValue = height.getText().toString();
        height.setText(heightTextValue);
    }


}
