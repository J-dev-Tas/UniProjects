package com.example.fitnessapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.GridView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ImageList extends AppCompatActivity {
    GridView gridView;
    ArrayList<Images> list;
    ImageAdaptor adaptor = null;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.image_list_activity);
        gridView = (GridView) findViewById(R.id.grid);
        list = new ArrayList<>();
        adaptor = new ImageAdaptor(this,R.layout.image_items,list);
        gridView.setAdapter(adaptor);
        Cursor cursor = Picturefrag.imageHelpler.getData("SELECT * FROM PHOTOS");
        list.clear();
        while(cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            byte[] image = cursor.getBlob(2);
            list.add(new Images(id,name,image));
        }
        adaptor.notifyDataSetChanged();
    }
}
