package com.example.fitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText User, Pass;
    Button Login, Reg;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        User = findViewById(R.id.user);
        Pass = findViewById(R.id.pass);
        Login = findViewById(R.id.login);
        Reg = findViewById(R.id.register);
        initdb();
    }
    public void initdb() {
        db = this.openOrCreateDatabase("Register.db", Context.MODE_PRIVATE, null);
        db.execSQL("create table if not exists Users(id INTEGER PRIMARY KEY AUTOINCREMENT, Username VARCHAR(255),Password VARCHAR(255))");
    }

    public void CreateUser(View view) {
        String username = User.getText().toString();
        String password = Pass.getText().toString();
        if (username.isEmpty() && password.isEmpty()) {
            Toast.makeText(this, "Please Input the username", Toast.LENGTH_SHORT).show();
        } else {
            ContentValues values = new ContentValues();
            values.put("Username", username);
            values.put("Password", password);
            db.insert("Users", null, values);
            Toast.makeText(this, "Account Created", Toast.LENGTH_LONG).show();

        }
    }

    public void CheckUser(View view) {
        String usercheck = User.getText().toString();
        String passcheck = Pass.getText().toString();
        int id = 1;
        try {
            Cursor cursor = db.rawQuery("select * from Users where Username  = '" + usercheck + "' and Password = '" + passcheck + "'", null);

            //setContentView(R.layout.activity_access_granted);
            //Intent i = new Intent (this,AccessGranted.class );
            //startActivity(i);
            if (cursor.getCount() >= 1) {
                Toast.makeText(this, "Access Granted", Toast.LENGTH_LONG).show();
                int GetID = 0;

                setContentView(R.layout.activity_bottom_navigation_page);
                Intent I = new Intent (this,BottomNavigationPage.class );
                I.putExtra("Iden",id);
                startActivity(I);


            }
        }catch(
                Exception ex)

        {
            Toast.makeText(this, "Account not found", Toast.LENGTH_LONG).show();
        }
    }


}
