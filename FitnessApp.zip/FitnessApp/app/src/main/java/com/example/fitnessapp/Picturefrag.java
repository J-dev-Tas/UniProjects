package com.example.fitnessapp;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import static android.app.Activity.RESULT_OK;
import static androidx.constraintlayout.widget.Constraints.TAG;


public class Picturefrag extends Fragment {
    ImageView imagetoupload, imagetodisplay;
    EditText uploadnameimage, pids;
    Button save, updatadb, display;
    TextView nameofimage;
    SQLiteDatabase db;
    private static final int CAMERA_REQUEST_CODE = 1;
    private Bitmap photo;
    public static ImageHelper imageHelpler;





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_picturefrag, container, false);
        Button btncam = (Button) v.findViewById(R.id.opencam);
        final EditText uploadnameimage = v.findViewById(R.id.edtname);
         Button save = (Button) v.findViewById(R.id.btnupload);
         display = v.findViewById(R.id.list);
        imagetoupload =  v.findViewById(R.id.cam);
        imageHelpler = new ImageHelper(getActivity(), "Image.db",null,1);
        imageHelpler.queryData("CREATE TABLE IF NOT EXISTS PHOTOS (id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR, image BLOG)");
        btncam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent camintnent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(camintnent,CAMERA_REQUEST_CODE);

            }


        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    imageHelpler.insertData(uploadnameimage.getText().toString().trim(),ImageViewToByte(imagetoupload));
                    Toast.makeText(getActivity(),"Added image", Toast.LENGTH_LONG).show();
                    uploadnameimage.setText("");
                    //imagetoupload.setImageResource(R.id.cam);
                }
                catch (Exception e){
                    e.printStackTrace();
                }



            }
        });
        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(),ImageList.class);
                startActivity(intent);
            }
        });

        // Inflate the layout for this fragment
        return v;
    }

    private byte[] ImageViewToByte(ImageView imageView){
       Bitmap bitmap = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
       ByteArrayOutputStream stream = new ByteArrayOutputStream();
       bitmap.compress(Bitmap.CompressFormat.PNG,100,stream);
       byte[] bytearray = stream.toByteArray();
       return bytearray;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            Log.d(TAG,"onActivityResult, done with photo");
             photo = (Bitmap) data.getExtras().get("data");
            imagetoupload.setImageBitmap(photo);
        }
    }

    private void saveToInternalStorage(Bitmap bitmapImage){
        String root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString();
        File myDir = new File(root + "/saved_images");
        myDir.mkdirs();
        Random generator = new Random();
        int n = 10000;
        n = generator.nextInt(n);
        String fname = "Image/"+ n +"jpeg";
        File file = new File (myDir, fname);
        if (file.exists ()) file.delete ();
        try {
            FileOutputStream out = new FileOutputStream(file);
            bitmapImage.compress(Bitmap.CompressFormat.JPEG, 50, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }



}