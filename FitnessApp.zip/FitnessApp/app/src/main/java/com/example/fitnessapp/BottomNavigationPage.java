package com.example.fitnessapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class BottomNavigationPage extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    private int value = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_navigation_page);
        BottomNavigationView navView = findViewById(R.id.nav_view);

        navView.setOnNavigationItemSelectedListener(this);
        loadFragment(new Homfrag());

    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;

        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment = null;
        switch (menuItem.getItemId()) {
            case R.id.navigation_home:
                fragment = new Homfrag();
                break;

            case R.id.navigation_calendar:
                fragment = new GraphFrag();
                break;

            case R.id.navigation_picture:
                fragment = new Picturefrag();
                break;
            case R.id.navigation_profile:
                fragment = new Profilefrag();
                break;
        }
        return loadFragment(fragment);
    }

    public int display() {
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            value = Integer.parseInt(extras.getString("Iden"));

        }
        return value;


    }
}
