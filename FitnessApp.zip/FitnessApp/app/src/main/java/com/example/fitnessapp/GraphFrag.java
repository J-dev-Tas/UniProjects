package com.example.fitnessapp;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

//import com.github.mikephil.charting.charts.LineChart;
//import com.github.mikephil.charting.data.Entry;
//import com.github.mikephil.charting.data.LineData;
//import com.github.mikephil.charting.data.LineDataSet;
//import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;


public class GraphFrag extends Fragment {
    DatabaseHelper2 userDB2;
    //LineChart mpLineChart;
    GraphView graph;
    int[] x= new int[3];
    int[] y= new int[3];
    //ArrayList<Integer> weight = new ArrayList<Integer>() ;
    //ArrayList<Integer> height = new ArrayList<Integer>() ;
    //String height = "";
    Cursor data;
    int counter = 0;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_graph, container, false);

        userDB2 = new DatabaseHelper2(getActivity());
        //v.setContentView(R.layout.activity_main);
        //mpLineChart = (LineChart) v.findViewById(R.id.linechart);
        //ReadData();

        LineGraphSeries<DataPoint> series;
        LineGraphSeries<DataPoint> series2;
        //an Object of the PointsGraphSeries for plotting scatter graphs
        graph = (GraphView) v.findViewById(R.id.linechart);
        graph.getViewport().setScalable(true);
        graph.getViewport().setScalableY(true);
        ReadData();
        series= new LineGraphSeries<>(data());
        series2= new LineGraphSeries<>(data2());
        series.setTitle("WEIGHT(KG), TARGET: 90KG");
        series2.setTitle("HEIGHT(CM), TARGET: 186CM");
        graph.getLegendRenderer().setVisible(true);
        //initializing/defining series to get the data from the method 'data()'
        series.setColor(Color.RED);
        series2.setColor(Color.GREEN);
        series.setDrawDataPoints(true);
        series2.setDrawDataPoints(true);
        graph.addSeries(series);
        graph.addSeries(series2);
        /*
        //Toast.makeText(getActivity(), Integer.toString(counter), Toast.LENGTH_LONG).show();
        LineDataSet lineDataSet1 = new LineDataSet(dataValues(),"Weight");
        LineDataSet lineDataSet2 = new LineDataSet(dataValues2(),"Height");
        lineDataSet2.setCircleColor(Color.RED);
        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(lineDataSet1);
        dataSets.add(lineDataSet2);
        LineData data = new LineData(dataSets);
        mpLineChart.setData(data);
        mpLineChart.invalidate();*/
        return v;
    }

    private DataPoint[] data2() {
        int n = y.length;
        DataPoint[] values = new DataPoint[n];
        //creating an object of type DataPoint[] of size 'n'
        for(int i=0;i<n;i++){
            DataPoint v = new DataPoint(i,y[i]);
            values[i] = v;
        }
        return values;
    }

    public DataPoint[] data(){
        int n = x.length;
        DataPoint[] values = new DataPoint[n];     //creating an object of type DataPoint[] of size 'n'
        for(int i=0;i<n;i++){
            DataPoint v = new DataPoint(i,x[i]);
            values[i] = v;
        }
        return values;
    }

    /*private List<Entry> dataValues2() {
        List<Entry> dataVals2 = new ArrayList<Entry>();
        int i = 0;
        int xaxis = 1;
        //while(i < counter-1) {

        //dataVals.add(new Entry(w,h));
        //dataVals.add(new Entry(weight.get(1),height.get(1)));
        dataVals2.add(new Entry(1,height.get(0)));
        dataVals2.add(new Entry(2,height.get(1)));
        //dataVals.add(new Entry(xaxis,weight.get(0)));
        i++;
        //}

        //dataVals.add(new Entry(1,24));
        //dataVals.add(new Entry(2,2));
        //dataVals.add(new Entry(3,10));
        //dataVals.add(new Entry(4,28));
        return dataVals2;
    }

    private ArrayList<Entry>dataValues(){

        ArrayList<Entry> dataVals = new ArrayList<Entry>();
        int i = 0;
        int xaxis = 1;
        //while(i < counter-1) {

            //dataVals.add(new Entry(w,h));
            //dataVals.add(new Entry(weight.get(1),height.get(1)));
            dataVals.add(new Entry(1,weight.get(0)));
            dataVals.add(new Entry(2,weight.get(1)));
            //dataVals.add(new Entry(xaxis,weight.get(0)));
            i++;
        //}

        //dataVals.add(new Entry(1,24));
        //dataVals.add(new Entry(2,2));
        //dataVals.add(new Entry(3,10));
        //dataVals.add(new Entry(4,28));
        return dataVals;
    }

    }*/public void ReadData() {
        data = userDB2.showData();

        if (data.getCount() == 0) {
            //display("Error", "No Data found.");
            Toast.makeText(getActivity(), "No Data found.", Toast.LENGTH_LONG).show();
            return;
        }


        while (data.moveToNext()) {

            //weight.add(Integer.parseInt(data.getString(3)));
            x[counter] = Integer.parseInt(data.getString(3));
            y[counter] = Integer.parseInt(data.getString(2));
            //height.add(Integer.parseInt(data.getString(2)));
            counter++;
            //display("All stored Data:", buffer.toString());


        }
    }


}
