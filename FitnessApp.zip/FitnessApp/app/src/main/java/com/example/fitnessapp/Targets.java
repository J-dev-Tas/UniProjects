package com.example.fitnessapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class Targets extends AppCompatActivity {
    DatabaseHelper2 userDB;

    Button btnAddData, btnViewData, btnUpdateData, btnDelete;
    EditText etName, etsurname, etTarget, etID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_targets);
        userDB = new DatabaseHelper2(this);

        etName = (EditText) findViewById(R.id.etNewName);
        etsurname = (EditText) findViewById(R.id.etNewSurname);
        etTarget = (EditText) findViewById(R.id.etNewTarget);
        btnAddData = (Button) findViewById(R.id.btnAddData);
        btnViewData = (Button) findViewById(R.id.btnViewData);
        btnUpdateData = (Button) findViewById(R.id.btnUpdateData);
        etID = (EditText) findViewById(R.id.etID);
        btnDelete = (Button) findViewById(R.id.btnDelete);

        AddData();
        ViewData();
        UpdateData();
        DeleteData();

    }
    public void AddData(){
        btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = etName.getText().toString();
                String surname = etsurname.getText().toString();
                String target = etTarget.getText().toString();

                boolean insertData = userDB.addData(name,surname,target);

                if(insertData == true){
                    Toast.makeText(Targets.this, "Data successfully inserted!",Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(Targets.this, "Something went wrong.",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    public void ViewData(){
        btnViewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor data = userDB.showData();

                if(data.getCount() == 0){
                    display("Error", "No Data found.");
                    return;

                }
                StringBuffer buffer = new StringBuffer();
                while(data.moveToNext()){
                    buffer.append("Weight ID: " + data.getString(0) + "\n");
                    buffer.append("Name: " + data.getString(1) + "\n");
                    buffer.append("Target Steps: " + data.getString(2) + "\n");
                    buffer.append("Target Weight: " + data.getString(3) + "\n");

                    display("All stored Data:", buffer.toString());


                }

            }
        });
    }

    public void display(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();

    }

    public void UpdateData(){
        btnUpdateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = etID.getText().toString().length();
                if(temp > 0){
                    boolean update = userDB.updateData(etID.getText().toString(),etName.getText().toString(),
                            etsurname.getText().toString(),etTarget.getText().toString());
                    if (update == true){
                        Toast.makeText(Targets.this, "Data uploaded.",Toast.LENGTH_SHORT).show();

                    }else{
                        Toast.makeText(Targets.this, "Something went wrong.",Toast.LENGTH_SHORT).show();
                    }

                }else{
                    Toast.makeText(Targets.this, "No height ID entered.",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    public void DeleteData(){
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int temp = etID.getText().toString().length();
                if(temp > 0){
                    Integer deleteRow = userDB.deleteData(etID.getText().toString());
                    if(deleteRow > 0){
                        Toast.makeText(Targets.this, "Delete successful.",Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(Targets.this, "Something went wrong.",Toast.LENGTH_SHORT).show();
                    }

                }else{
                    Toast.makeText(Targets.this, "Something went wrong.",Toast.LENGTH_SHORT).show();

                }
            }
        });

    }


}
