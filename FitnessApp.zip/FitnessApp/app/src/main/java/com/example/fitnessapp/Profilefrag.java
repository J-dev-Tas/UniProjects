package com.example.fitnessapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class Profilefrag extends Fragment {
private Button edt,daily,goals;
    private SharedPreferences savedweight,savedheight;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View v =  inflater.inflate(R.layout.fragment_profilefrag, container, false);
        edt  = (Button) v.findViewById(R.id.editweight);
        daily = (Button)v.findViewById(R.id.weightchange);
        goals = (Button)v.findViewById(R.id.edit);
        edt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                openActivity();

            }
        });
        daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              openDaily();
            }
        });

        goals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             openGoals();
            }
        });
        return v;
    }
    public void openActivity(){
        Intent int1 = new Intent(getActivity(),EditProfile.class);
        startActivity(int1);
    }
    public void openDaily(){
        Intent int2 = new Intent(getActivity(),Log.class);
        startActivity(int2);
    }
    public void openGoals(){
        Intent i3 = new Intent(getActivity(),Targets.class);
        startActivity(i3);
    }


}
